﻿//EJercicios de Lab #11 - Kevin Joel Atz Amaya - Carne: 2001025
using System;
using System.Diagnostics.CodeAnalysis;
class Program {
 static void Main() {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ejercicio 1
Console.WriteLine("Ingresar números hasta que la suma de estos sea mayor o igual a 100.");

int num = 0;
int suma = 0;
int CantNum = 0;

while(suma < 100)//Con el ciclo While se declara que si la cantidad sumada es menor a 100 se pedira otro numero para sumarse hasta que llegue a 100 o mayor
{
    Console.WriteLine("Ingresa un numero");
    num = Convert.ToInt32(Console.ReadLine());
    suma += num;
    CantNum = CantNum + 1;// se suma la cantidad de numeros que se han ingresado
 }

Console.WriteLine("La suma es de: " + suma); 
Console.WriteLine("La cantidad de numeros sumados es: " + CantNum); 

Console.ReadKey();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ejercicio 2
int N = 0;
int M = 0;
Console.WriteLine("Tablas de multiplicar");
Console.WriteLine("Ingrese el numero que desea saber su tabla de multiplicar del 1 al 10");
N = Convert.ToInt32(Console.ReadLine());

for(int i = 1; i<=10; i++)//Con el ciclo For se declara que todos los numero menores o igual a 10 se multiplicaran por el numero que ingresaron
{
    M = i * N;
    Console.WriteLine( N + " * " + i + " = " + M);// se muestra de manera ordenada la tabla
}
Console.ReadKey();

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ejercicio 3
Random R = new Random();
int Random = R.Next(1,51);
int NumUsuario;

Console.WriteLine("Adivina el numero secreto entre el 1 y 50");
Console.WriteLine("Ingrese el numero");
NumUsuario = Convert.ToInt32(Console.ReadLine());

do//En el Do indicamos las condiciones que se realizara con el numero ingresado con respecto al numero random
{
    if (NumUsuario > 0 && NumUsuario < 51)// si el numero ingresado esta entre 1 y 50 se realizara la busqueda el numero random
    {
        if (Random < NumUsuario)// Si el numero random es menor a el numero ingresado se le indicara y se pedira que lo intente otra vez
        {
            Console.WriteLine("El número es menor. Intenta de nuevo: ");
            NumUsuario = Convert.ToInt32(Console.ReadLine());
        }

        if (Random > NumUsuario)// Si el numero random es mayor a el numero ingresado se le indicara y se pedira que lo intente otra vez
        {
            Console.WriteLine("El número es mayor. Intenta de nuevo: ");
            NumUsuario = Convert.ToInt32(Console.ReadLine());
        }
    }
    else // Si el numero ingresado no esta en el rango del 1 al 50 se indicara que no es un numero participante
    {
        Console.WriteLine("El numero ingresado no esta en el rango entre 1 y 50. Intenta de nuevo:");
        NumUsuario = Convert.ToInt32(Console.ReadLine());
    }
}

while (NumUsuario != Random );//En el While se declara que seguira el ciclo mientra el numero ingresado sea diferente al random

    if (NumUsuario == Random)//Se delcara la condicion cuando sean iguales el numero ingresado y el random
    {
        Console.WriteLine("¡Felicidades! Has adivinado el número");
    }

Console.ReadKey();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ejercicio 4
int cantLineas = 1;

Console.WriteLine("Triangulo de asteriscos");
Console.WriteLine("Ingrese un numero");
int numero =Convert.ToInt32(Console.ReadLine());

while(cantLineas <= numero)//En el ciclo While se tomara la cantidad de lineas que sean menor o igual al numero ingresado
{
    for(int ast = 1;ast <= cantLineas; ast++ )//En el ciclo For se tomaran todos los numero que sean menor o igual a la cantidad de lineas 
    {
        Console.Write("*",ast);//Se imprime el caracter * y la cantidad de * que habran segun la cantidad de lineas
    }
     cantLineas++;
     Console.WriteLine("");
 }

Console.ReadKey();

 }
}