﻿//Kevin//EJercicios de Lab #12 - Kevin Joel Atz Amaya - Carne: 2001025
using System;
class Program
{
 static void Main()
 {

//////Ejercicio 1////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // Pedimos al usuario que ingrese una palabra y la convertimoes en minusculas
 Console.Write("Ingresa una palabra: ");
 string palabra = Console.ReadLine().ToLower();
 // Creamos una nueva cadena vacía para almacenar la palabra invertida.
 string invertida = "";
 // Recorremos la palabra de atrás hacia adelante.
 for (int i = palabra.Length - 1; i >= 0; i--)
 {
 // Vamos agregando cada carácter a la nueva cadena.
 invertida += palabra[i];
 }
 // Mostramos el resultado.
 Console.WriteLine("Palabra invertida: " + invertida);

//Se verifica si es un polindromo o no
if (palabra == invertida)//Si la palabra ingresada y convertida en minusculas es igual a la invertida es un palindromo
{
    Console.Write("Es un palindromo");
}

else//Si la palabra ingresada y convertida en minusculas no es igual a la invertida no es un palindromo
{
    Console.Write("No es un palindromo");
}

Console.WriteLine();
Console.ReadKey();

//Ejercicio 2 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Solicita al usuario una frase.
 Console.Write("Ingresa una frase: ");
 string frase = Console.ReadLine().ToLower(); // Convertimos a minúsculas parasimplificar la comparación.
 // Inicializamos contador.
 int contadorA = 0;
 int contadorE = 0;
 int contadorI = 0;
 int contadorO = 0;
 int contadorU = 0;
 
 // Recorremos cada letra de la frase.
 // el comando foreach tiene el siguiente funcionamiento: Recorre cada uno de los caracteres que están en la cadena frase. 
 // En cada vuelta del ciclo, el carácter actual se guarda en la variable llamada letra. 
 // La variable letra tiene tipo char (carácter individual).
 foreach (char letra in frase)
 {
 // Si la letra es a, aumentamos el contadorA.
 if ("a".Contains(letra))
 {
    contadorA++;
 } 
 // Si la letra es e, aumentamos el contadorE.
 if ("e".Contains(letra))
 {
    contadorE++;
 } 
 // Si la letra es i, aumentamos el contadorI.
  if ("i".Contains(letra))
 {
    contadorI++;
 } 
 // Si la letra es o, aumentamos el contadorO.
  if ("o".Contains(letra))
 {
    contadorO++;
 } 
 // Si la letra es u, aumentamos el contadorU.
 if ("u".Contains(letra))
 {
    contadorU++;
 } 
 }

 // Mostramos el resultado.
 Console.WriteLine("Cantidad de a en la frase: " + contadorA);
 Console.WriteLine("Cantidad de e en la frase: " + contadorE);
 Console.WriteLine("Cantidad de i en la frase: " + contadorI);
 Console.WriteLine("Cantidad de o en la frase: " + contadorO);
 Console.WriteLine("Cantidad de u en la frase: " + contadorU);
 
 Console.WriteLine();
 Console.ReadKey();


//Ejercicio 3 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // Pedimos al usuario la frase.
 Console.Write("Ingresa una frase: ");
 string fra = Console.ReadLine();
 // Pedimos el carácter que se desea reemplazar.
 Console.Write("Palabra a reemplazar: ");
 string original = Console.ReadLine();
 Console.WriteLine();
 // Pedimos el nuevo carácter.
 Console.Write("Nueva palabra: ");
 string nuevo = Console.ReadLine();
 Console.WriteLine();
 // Reemplazamos el carácter usando Replace.
 string modificada = fra.Replace(original, nuevo);
 // Mostramos el resultado.
 Console.WriteLine("Frase modificada: " + modificada);

 Console.WriteLine();
 Console.ReadKey();

 }
}