﻿using System;
using System.Diagnostics.CodeAnalysis;
using Lab15.Clases;
class Program
{

     static void Main(string[] args)
    {
        AgendarLaboratorio agenda = new AgendarLaboratorio();
        string opcionElegido = "";
        int opciones = 0;

         while (opciones != 4)
        {
            Console.WriteLine("MENÚ");
            Console.WriteLine("Ingrese el numero de las opcion que desea:");
            Console.WriteLine("1. Agregar nueva reservacion");
            Console.WriteLine("2. Mostrar todas las reservaciones ordenadas por fecha");
            Console.WriteLine("3. Buscar reservaciones por nombre del responsable");
            Console.WriteLine("4. Salir del sistema");
            opcionElegido = Console.ReadLine();
            
            if (int.TryParse(opcionElegido, out opciones))
            {
                if (opciones >= 1 && opciones <= 4)
                {

            switch (opciones)
            {
                case 1:
                    Console.WriteLine("Agregar nueva reservacion");
                    Console.WriteLine();
                    AgregarReserva(agenda);
                    break;

                case 2:
                    Console.WriteLine("Mostrar todas las reservaciones ordenadas por fecha");
                    Console.WriteLine();
                    agenda.mostrarReservasOrdenadas();
                    break;

                case 3:
                    Console.WriteLine("Buscar reservaciones por nombre del responsable");
                    Console.WriteLine();
                    string nombre = Console.ReadLine();
                    agenda.BuscarPorResponsable(nombre);
                    break;

                case 4:
                    Console.WriteLine("Salir del sistema");
                    Console.WriteLine("Gracias por reservar con nosotros, vuelva pronto");
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Opción inválida, intente otra ves");
                    break;
            }

        } 
    
    }

    static void AgregarReserva(AgendarLaboratorio agenda)
    {
        Console.Write("Nombre del responsable: ");
        string responsable = Console.ReadLine();

        Console.Write("Día (1-31): ");
        int dia = int.Parse(Console.ReadLine());

        Console.Write("Mes (1-12): ");
        int mes = int.Parse(Console.ReadLine());

        Console.Write("Año: ");
        int año = int.Parse(Console.ReadLine());

        Console.Write("Hora de inicio (Nuestro horario es de 8:00 Am para las 20:00 Pm): ");
        int HoraInicio = int.Parse(Console.ReadLine());

        Console.Write("Hora de fin (Nuestro horario es de 8:00 Am para las 20:00 Pm): ");
        int HoraFin = int.Parse(Console.ReadLine());

        Fecha fecha = new Fecha(dia, mes, año, HoraInicio, HoraFin);
        if (!fecha.EsValida())
        {
            Console.WriteLine("La fecha u horario no son válidos");
            return;
        }

        Console.Write("Cantidad de computadoras (Peudes reservar de 1 hasta 40 computadoras): ");
        int CantidadDeComputadoras = int.Parse(Console.ReadLine());

        Reserva ReservaDeCompu = new Reserva(responsable, fecha, CantidadDeComputadoras);
        if (!ReservaDeCompu.ValidaCantidadCompu())
        {
            Console.WriteLine("Cantidad de computadoras inválido, recuerda que solo puedes reservar de 1 hasta 40 computadoras ");
            return;
        }

        if (agenda.agregarReserva(ReservaDeCompu))
        {
            Console.WriteLine("Reservacion agregada exitosamente.");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("No se pudo agregar la reservacion (capacidad llena o verifica tus datos).");
        }
    }
   }
   }
}