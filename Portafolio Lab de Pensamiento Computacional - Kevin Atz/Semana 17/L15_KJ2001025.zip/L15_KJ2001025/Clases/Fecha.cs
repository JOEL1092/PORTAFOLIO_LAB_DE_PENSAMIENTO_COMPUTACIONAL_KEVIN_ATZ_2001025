namespace Lab15.Clases
{
    public class Fecha
    {
        private int dia;
        private int mes;
        private int año;
        private int HoraInicio;
        private int HoraFin;

        public Fecha (int dia, int mes, int año, int HoraInicio, int HoraFin)
        {
            this.dia = dia;
            this.mes = mes;
            this.año = año;
            this.HoraInicio = HoraInicio;
            this.HoraFin = HoraFin;
        }

        public void SetDia(int dia)
        {
            this.dia = dia;
        }
        public int GetDia()
        {
            return this.dia;
        }

        public void SetMes(int mes)
        {
            this.mes = mes;
        }
        public int GetMes()
        {
            return this.mes;
        }
        public void SetAño(int año)
        {
            this.año = año;
        }
        public int GetAño()
        {
            return this.año;
        }
        public void SetHoraInicio(int HoraInicio)
        {
            this.HoraInicio = HoraInicio;
        }
        public int GetHoraInicio()
        {
            return this.HoraInicio;
        }
        public void SetHoraFin(int HoraFin)
        {
            this.HoraFin = HoraFin;
        }
        public int GetHoraFin()
        {
            return this.HoraFin;
        }

        public bool EsValida()
        {
        if (mes < 1 || mes > 12 || dia < 1)
            return false;

        int[] DiasDeCadaMes = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if (dia > DiasDeCadaMes[mes - 1])
        {
            return false;
        }
            
        if (HoraInicio < 8 || HoraInicio > 20 || HoraFin < 8 || HoraFin > 20 || HoraInicio >= HoraFin)
        {
            return false;
        };

        return true;
        }
    };

}