using System.Security.Cryptography.X509Certificates;

namespace Lab15.Clases
{
    public class AgendarLaboratorio
    {
        private Reserva[] reservasLaboratorio = new Reserva[50];
        private int totalReservas = 0;

        public bool agregarReserva (Reserva nuevo)
        {
           if (totalReservas >= 50)
            {
                return false;
            } 

            Fecha IngresarReserva = nuevo.GetFecha();

                int IngresarDia = IngresarReserva.GetDia();
                int IngresarMes = IngresarReserva.GetMes();
                int IngresarAño = IngresarReserva.GetAño();
                int IngresarHoraInicio = IngresarReserva.GetHoraInicio();
                int IngresarHoraFinal = IngresarReserva.GetHoraFin();

            for (int i = 0; i < totalReservas; i++)
            {
                Fecha Creada = reservasLaboratorio[i].GetFecha();

                if (Creada.GetDia() == IngresarDia && Creada.GetMes() == IngresarMes && Creada.GetAño() == IngresarAño)
                {
                    int HoraI = Creada.GetHoraInicio();
                    int HoraF = Creada.GetHoraFin();

                    if (!(HoraF <= IngresarHoraInicio || IngresarHoraFinal <= HoraI))
                    {
                        return false;
                    }
                }
            }

            reservasLaboratorio[totalReservas] = nuevo;
            totalReservas++;
            return true;    
        }



        public void mostrarReservasOrdenadas()
        {
            for (int i = 0; i < totalReservas; i++)
            {
                int valorMasbajo = i;
                for (int j = i + 1; j < totalReservas; j++)
                {
                    Fecha fecha1 = reservasLaboratorio[valorMasbajo].GetFecha();
                    Fecha fecha2 = reservasLaboratorio[j].GetFecha();

                    if ( fecha2.GetAño() < fecha1.GetAño() || (fecha2.GetAño() == fecha1.GetAño() && fecha2.GetMes() < fecha1.GetMes()) ||
                        (fecha2.GetAño() == fecha1.GetAño() && fecha2.GetMes() == fecha1.GetMes() && fecha2.GetDia() < fecha1.GetDia()) ||
                        (fecha2.GetAño() == fecha1.GetAño() && fecha2.GetMes() == fecha1.GetMes() && fecha2.GetDia() == fecha1.GetDia() &&
                        fecha2.GetHoraInicio() < fecha1.GetHoraInicio()))
                    {
                        valorMasbajo = j;
                    }
                }

                    if (valorMasbajo != i)
                    {
                        Reserva temp = reservasLaboratorio[i];
                        reservasLaboratorio[i] = reservasLaboratorio[valorMasbajo];
                        reservasLaboratorio[valorMasbajo] = temp;
                    }
            }

            for (int i = 0; i < totalReservas; i++)
            {
                reservasLaboratorio[i].MostrarReserva();
                Console.WriteLine();
            }

        }


        public void BuscarPorResponsable(string nombre)
        {
            bool Buscar = false;

            for (int i = 0; i < totalReservas; i++)
            {
                if (reservasLaboratorio[i].GetResponsable().ToLower() == nombre.ToLower())
                    {
                        reservasLaboratorio[i].MostrarReserva();
                        Console.WriteLine();
                        Buscar = true;
                    }
            }
            if (!Buscar)
            {
                Console.WriteLine("No se encontraron reservaciones con el responsable: " + nombre);
            }
        }
    }
}
