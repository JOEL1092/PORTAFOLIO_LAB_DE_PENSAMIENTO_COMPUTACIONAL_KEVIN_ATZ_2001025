using System.Security.Cryptography.X509Certificates;

namespace Lab15.Clases
{
    public class Reserva
    {
        private String responsable;
        private Fecha fecha;
        private int CantidadDeComputadoras;
    
        public Reserva (string responsable, Fecha fecha, int CantidadDeComputadoras)
        {
            this.responsable = responsable;
            this.fecha = fecha;
            this.CantidadDeComputadoras = CantidadDeComputadoras;
        }

        public void SetResponsable(string responsable)
        {
            this.responsable = responsable;
        }
        public string GetResponsable()
        {
            return this.responsable;
        }

         public void SetCantidadDeComputadoras(int CantidadDeComputadoras)
        {
            this.CantidadDeComputadoras = CantidadDeComputadoras;
        }
        public int GetCantidadDeComputadoras()
        {
            return this.CantidadDeComputadoras;
        }
        
        public void SetFecha (Fecha fecha)
        {
            this.fecha = fecha;
        }

        public  Fecha GetFecha()
        {
            return this.fecha;
        }

       public bool ValidaCantidadCompu() 
       {
            if (CantidadDeComputadoras < 1 || CantidadDeComputadoras > 40) 
            { 
                return false; 
            } 
                return true; }

        public void MostrarReserva()
        {
        Console.WriteLine("Responsable: " + this.GetResponsable());
        Console.WriteLine($"Fecha: {fecha.GetAño()}-{fecha.GetMes().ToString().PadLeft(2, '0')}-{fecha.GetDia().ToString().PadLeft(2, '0')}");
        Console.WriteLine("Cantidad de Computadoras: " + this.GetCantidadDeComputadoras());
        }

    };

}