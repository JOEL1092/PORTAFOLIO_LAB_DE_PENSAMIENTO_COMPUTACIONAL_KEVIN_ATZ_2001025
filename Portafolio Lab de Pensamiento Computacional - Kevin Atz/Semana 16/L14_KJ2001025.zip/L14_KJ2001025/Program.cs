﻿
//EJercicios de Lab #13 - Kevin Joel Atz Amaya - Carne: 2001025
using System;
using System.Security.Cryptography.X509Certificates;
/*
class Program {
//Ejercicio #1: Manejo de vectores en C#

static int Cant;
static int[] Arreglo = new int [0];
static void Main() 
{
//El usuario podrá seleccionar entre las siguientes opciones:
Console.WriteLine("Operaciones con vector de enteros");
Console.WriteLine();
string opcionElegido = "";
int opciones = 0;



  while (opciones != 7)
{
        Console.WriteLine(); 
        Console.WriteLine("Seleccione una de las siguientes opciones:");
        Console.WriteLine("1. Introducir valores");
        Console.WriteLine("2. Leer datos");
        Console.WriteLine("3. Desplegar los datos");
        Console.WriteLine("4. Buscar un dato");
        Console.WriteLine("5. Actualizar un dato");
        Console.WriteLine("6. Ordenar los valores");
        Console.WriteLine("7. Salir");
        Console.WriteLine();
        opcionElegido = Console.ReadLine();
           
    if (int.TryParse(opcionElegido, out opciones))
    {
        if (opciones >= 1 && opciones <= 7)
        {
            switch (opciones)
            {
            case 1://Introducir valores
            Console.WriteLine("Introducir valores");
            Console.WriteLine();
            IntroducirValores();
            break;

            case 2://Leer datos
            Console.WriteLine("Leer datos");
            Console.WriteLine();
            LeerValores();
            break;

            case 3://Desplegar los datos
            Console.WriteLine("Desplegar los datos");
            Console.WriteLine();
            DesplegarValores ();
            break;

            case 4://Buscar un dato
            Console.WriteLine("Buscar un dato");
            Console.WriteLine();
            BuscarValores ();
            break;

            case 5://Actualizar un dato
            Console.WriteLine("Actualizar un dato");
            Console.WriteLine();
            ActualizarValores ();
            break;

            case 6://Ordenar los valores
            Console.WriteLine("Ordenar los valores");
            Console.WriteLine();
            OrdenarValores ();
            break;

            case 7://Salir del programa

                Console.WriteLine("Has salido del programa");
                Console.WriteLine();
                Environment.Exit(0);
                
            break;

            }
        }
    else
    {
        Console.WriteLine("valor inválida, eliga el valor correcto de las opciones dadas");
        Console.WriteLine();
    }
}

 }

 static void IntroducirValores ()
 {
    //Se le solicita al usuario la cantidad de valores que desea en el vector
    Console.Write("Ingrese la cantidad de valores que desea en el vector: ");
    Cant = int.Parse(Console.ReadLine());
    //Creamos el arreglo con los parametros 
    Arreglo = new int [Cant];

 

    Console.WriteLine("Ingrese los valores del vector: ");//solicitamos cada valor del arreglo al usuario
    for(int i = 0; i < Cant; i++)//contamos la cantidad de datos en el arreglo
    {
      string ValorIngresado = Console.ReadLine();
        
        if (int.TryParse(ValorIngresado, out int valor))// si el usuario ingresa un valor, lo guardamos
        {
            Arreglo[i] = valor; // Guardamos el valor ingresado
        }
    }
    Console.WriteLine();
    Console.WriteLine("Vector guardado");
    Console.WriteLine();
    }
 }

 static void LeerValores ()
 
 {
    ValidarIngresoArreglo(Arreglo);

    if(Arreglo.Length != 0)
    {
    Console.Write("los valores del vector guardado son: ");//mostramos los valores que ingreso el usuario
    for (int i = 0; i < Cant; i++)
    {
        if(Arreglo[i]!=0)
        {
            Console.Write(Arreglo[i] + " ");
        }
    }
    Console.WriteLine(); 
    }
 }


static void DesplegarValores ()
 {
    ValidarIngresoArreglo(Arreglo);

    if(Arreglo.Length != 0)
    {
    Console.Write("El vector completo es el siguiente: ");
    for (int i = 0; i < Cant; i++)//leemos cada dato del arreglo 
        {
            Console.Write(Arreglo[i] + " ");//mostramos cada dato leido del arreglo
        }
    Console.WriteLine();
    }
 }


 static void BuscarValores ()
 {
    ValidarIngresoArreglo(Arreglo);

    if(Arreglo.Length != 0)
    {
        Console.Write("Ingrese el numero que desea buscar: ");
        int Numero = int.Parse(Console.ReadLine());
        Console.WriteLine();
        Console.WriteLine("Posiciones encontradas del numero " + Numero + " en el vector:");
        int verdadero = 0;//este contador indicara si hay o no el numero a buscar en la matriz
        for (int i = 0; i < Cant; i++)// contamos la posicion de filas
        {
                if (Arreglo[i] == Numero)// si el valor de la posicion actual es igual al valor a buscar se mostrara la posicion
                {
                    Console.WriteLine(i);
                    verdadero ++;//aumenta el contador queriendo decir que si se encuentra el numero en el vector
                }
        }

        if( verdadero == 0)//si el contador aun sigue en 0 quiere decir que no encontro el numero a buscar en el vector
            {
                Console.WriteLine("No se encuentra el numero en este vector");
            }
    }
    
 }

  static void ActualizarValores ()
 {
    ValidarIngresoArreglo(Arreglo);

    if(Arreglo.Length != 0)
    {
        DesplegarValores();
        Console.WriteLine("Su vector es de 0 a {0} posiciones", Arreglo.Length - 1);
        Console.Write("Ingrese la posicion que desea actualizar el valor: ");

        if (int.TryParse(Console.ReadLine(), out int Posicion))
        {
            if (Posicion >= 0 && Posicion < Arreglo.Length)
            {
                Console.WriteLine("El valor en la posición "+ Posicion + " es " + Arreglo[Posicion]);

                Console.WriteLine("Ingrese el numero con el cual se va a actualizar");
                if (int.TryParse(Console.ReadLine(), out int nuevo))
                {
                Arreglo[Posicion] = nuevo;
                Console.WriteLine("Valor actualizado correctamente.");
                DesplegarValores();
                Console.WriteLine();
                }
                else
                {
                Console.WriteLine("Valor ingresado no válido. Debe ser un número entero.");
                }
            }
            else
            {
                Console.WriteLine("La posición ingresada esta fuera del rango del vector");
            }
        }        
    }
 }

  static void OrdenarValores ()
 {
    ValidarIngresoArreglo(Arreglo);
    if(Arreglo.Length != 0)
    {
    int ValorDeIntercambio;
        for (int i = 0; i < Arreglo.Length - 1; i++)
        {
            for (int j = i + 1; j < Arreglo.Length; j++)
            {
                if (Arreglo[i] > Arreglo[j])
                {
                    ValorDeIntercambio = Arreglo[i];
                    Arreglo[i] = Arreglo[j];
                    Arreglo[j] = ValorDeIntercambio;
                }
            }
        }
    Console.WriteLine("Se ordeno de menor a mayor los valores del vector");
    DesplegarValores();
    Console.WriteLine();
    }
 }

  static void ValidarIngresoArreglo (int [] Arreglo)
 {
    if (Arreglo.Length == 0)
    {
        DesplegarValores();
        Console.WriteLine("El vector está vacío, introdusca los valores del vector");
        Console.WriteLine();
    }
 }
*/


//Ejercicio #2: Gestión de Inventario con Estructuras en C#

public struct Producto
{
    public string nombre;
    public int Codigo;
    public double Precio;
    public int Cantidad;   
    
}

class Program
{
static Producto[] inventario = new Producto[5];
static int ProductosAgregados = 0;
static double total= 0;


static void Main(string [] args) 
{
//El usuario podrá seleccionar entre las siguientes opciones:

Console.WriteLine("Gestion de Inventario");
Console.WriteLine();
string opcionElegido = "";
int opciones = 0;


  while (opciones != 5)
{
        Console.WriteLine(); 
        Console.WriteLine("Seleccione una de las siguientes opciones:");
        Console.WriteLine("1. Agregar producto");
        Console.WriteLine("2. Modificar precio de un producto");
        Console.WriteLine("3. Mostrar productos");
        Console.WriteLine("4. Calcular valor total del inventario");
        Console.WriteLine("5. Salir");
        Console.WriteLine();
        opcionElegido = Console.ReadLine();
           
    if (int.TryParse(opcionElegido, out opciones))
    {
        if (opciones >= 1 && opciones <= 5)
        {
            switch (opciones)
            {
            case 1://Agregar producto
                Console.WriteLine("Agregar producto");
                Console.WriteLine();
                AgregarProducto ();
            break;

            case 2://Modificar precio de un producto
                Console.WriteLine("Modificar precio de un producto");
                Console.WriteLine();
                ModificarPrecioDeProducto ();
            break;

            case 3://Mostrar productos
                Console.WriteLine("Mostrar productos");
                Console.WriteLine();
                MostrarProductos ();
            break;

            case 4://Calcular valor total del inventario"
                Console.WriteLine("Calcular valor total del inventario");
                Console.WriteLine();
                CalcularValorTotalDelInventario();
            break;

            case 5://Salir del programa

                Console.WriteLine("Has salido del programa");
                Console.WriteLine();
                Environment.Exit(0);
                
            break;

            }
        }
    }

    else
    {
        Console.WriteLine("valor inválida, eliga el valor correcto de las opciones dadas");
        Console.WriteLine();
    }
}

 static void AgregarProducto ()
 {
    ValidarProducto (inventario);
    if (ProductosAgregados < inventario.Length)
        {
            Console.WriteLine();
            Console.WriteLine("Su inventario contiene " + inventario.Length + " espacios para productos");
            Console.WriteLine();
    
        for(int i = 0; i < inventario.Length; i++ )
            {
                Console.Write("Ingrese el nombre del producto: ");
                inventario[i].nombre = Console.ReadLine();
                Console.Write("Ingrese el codigo del producto: ");
                inventario[i].Codigo = int.Parse(Console.ReadLine());
                Console.Write("Ingrese el precio del producto: Q ");
                inventario[i].Precio = double.Parse(Console.ReadLine());
                Console.Write("Ingrese la cantidad del producto: ");
                inventario[i].Cantidad = int.Parse(Console.ReadLine());
                Console.Write("Producto Guardado");
                Console.WriteLine();
                ProductosAgregados++;


            }

        }
 }

 static void ModificarPrecioDeProducto ()
 {
    ValidarProducto (inventario);

    Console.Write("Ingrese el nombre del producto a modificar: ");
    string ProductoBuscado = Console.ReadLine();
    int cont = 0;

    for (int i = 0; i < ProductosAgregados; i++)
    {
        if (inventario[i].nombre == ProductoBuscado)
        {
            Console.WriteLine("Precio actual: Q " + inventario[i].Precio );
            Console.Write("Ingrese el nuevo precio: ");
            inventario[i].Precio = double.Parse(Console.ReadLine());
            Console.WriteLine("Se ha modificado el precio ");
            cont ++;
            break;
        }
    }

    if (cont == 0);
    {
        Console.WriteLine("Producto no esta en el inventario.");

    }

 }

 static void MostrarProductos ()
 {
    ValidarProducto (inventario);

       if (ProductosAgregados == 0)
    {
        Console.WriteLine("El inventario está vacío, introdusca los productos");
        Console.WriteLine();
    }
        for(int i = 0; i < inventario.Length; i++ )
                {
                    Console.WriteLine("Producto: ");
                    Console.Write("Nombre: " + inventario[i].nombre+ " ");
                    Console.Write("Codigo: " + inventario[i].Codigo+ " ");
                    Console.Write("Precio: " + inventario[i].Precio+ " ");
                    Console.Write("Cantidad: " + inventario[i].Cantidad + "");
                    Console.WriteLine();

                    
                }
        }


 }

 static void CalcularValorTotalDelInventario()
 {
    ValidarProducto (inventario);
    if (ProductosAgregados == 0)
    {
        Console.WriteLine("El inventario está vacío, introdusca los productos");
        Console.WriteLine();
    }
    
    for(int i = 0; i < inventario.Length; i++ )
        {
            total += inventario[i].Precio * inventario[i].Cantidad ;  
        }
        Console.Write("El valor total del inventario es de: Q" + total );
        Console.WriteLine();

    }

 

static void ValidarProducto (Producto [] inventario)
 {
 
    if (ProductosAgregados > inventario.Length )
        {
            Console.WriteLine("No puedes ingresar mas productos, el inventario esta lleno");
            Console.WriteLine();
        }
        }

 }












