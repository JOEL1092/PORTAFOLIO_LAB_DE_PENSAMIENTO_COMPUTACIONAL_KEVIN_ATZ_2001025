﻿//EJercicios de Lab #13 - Kevin Joel Atz Amaya - Carne: 2001025
using System;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
class Program {

/*
//Ejercicio 1: DNI
 static void Main() {// Funcion pricipal

//variables que van a recibir los digitos del DNI y la letra
int numeroDNI;
char letraDNI;

do{//se inicia un ciclo con el procedimiento 
    Console.WriteLine("Ingresa tu DNI (8 digitos)");// se solicita los 8 digitos del el DNI
    numeroDNI = int.Parse(Console.ReadLine());


    Console.WriteLine("Ingresa la letra de tu DNI");// se solicita la letra del DNI
    letraDNI = Console.ReadLine().ToUpper()[0];// guardamos la letra, la pasamos a mayusculas y definicmos que unicamente solo la primera letra tomara por si ingresa mas de una

    comprueba_letra_dni (numeroDNI, letraDNI);//llamamos la funcion en donde valida si es correcto la letra del DNI
}

while(letra_dni(numeroDNI) != letraDNI);//se pedira el DNI y la letra hasta que la letra ingresada coincida con la letra correcta se cerrara el ciclo

}

static char letra_dni (int numeroDNI){// esta funcion estara el proceso para encontrar la letra correcta

    int num = numeroDNI % 23;// se divide el DNI entre 23 y el residuo sera el numero de la letra correcta

    string Cad = "TRWAGMYFPDXBNJZSQVHLCKE";// se incerta el orden de las letra del 1 al 23
    Char Cad1 = Convert.ToChar(Cad.Substring(num,1));// se busca la letra por medio de la posicion segun el numero de la letra
    
    return Cad1;//el dato que se retornara la funcion es la letra correcta
} 
static void comprueba_letra_dni (int numeroDNI, char letraDNI){// esta funcion es donde se validara si la letra ingresada es la letra correcta
    
    char letraCorrecta = letra_dni(numeroDNI);//se llama la funcion de la letra correcta y se aguarda en una variable

     if (letraCorrecta == letraDNI){// verificamos si la letra correcta es igual a la letra ingresada
        Console.WriteLine("Bienvenido");// le damos la bienvenida y acceso al usuario
     }

     else { //si no es es igual las letras entonces le indicamos que hay un error
        Console.WriteLine("Ha cometido Usted un error al ingresar los datos, intenta otra ves");
        Console.ReadKey();
        Console.WriteLine();
     }
}


//Ejercicio 2: Validacion de contraseña

static void Main(){//Funcion principal

    string contraseñaCorrecta = "Contra123";//La contraseña correcta es Contra123
    SolicitarContraseña(contraseñaCorrecta);//llamamos la funcion que solicita la contraseña y valida si es la correcta
    Console.ReadKey();//
}
static void SolicitarContraseña(string contraseñaCorrecta){//esta funcion solicitamos la contrseña y damos 3 intentos

    for (int i = 1; i < 4; i++  ){//condicionamos los intentos con un for a 3 intentos

    Console.WriteLine("Ingrese la contraseña");
    string contraseña= Console.ReadLine();//guardamos la contraseña ingresada por el usuario

    bool validacion = ValidarFormato(contraseña);//guardamos el valor boleano dado por la funcion que verifica si cumple con las condiciones la contraseña

    if ( validacion == false)// si las condiciones de la contraseña no cumplen con lo solcitado le indicamos al usuario 
    {
        Console.WriteLine("contraseña inválido. La contraseña debe tener al menos 8 caracteres, una mayúscula y un número");
    }
    if (contraseña == contraseñaCorrecta )// Si la contraseña ingresada es igual a la contraseña correcta le damos acceso
    {
        Console.WriteLine("Acceso permitido");
        return;
    }
    else // si no le degamos el acceso
    {
        Console.WriteLine("Acceso denegado");
    }

    }

}
static bool ValidarFormato(string contraseña){// esta funcion verifica las condiciones para la contraseña

    if (contraseña.Length < 8)// contamos los caracteres de la contraseña ingresada y verificamos si tiene menos de 8 caracteres
    return false;// si tiene menos de 8 mandamos un valor valso
    bool Mayusculas = false;//declaramos una variable para las mayusculas con valor falso
    bool num = false;//declaramos una variable para los numeros con valor falso
    
    foreach (char c in contraseña)// realizamos una lectura a cada caracter de la contraseña y la aguardamos momentaneamente en la variable c para luego validar
        {
            if (char.IsUpper(c))// si el caracter que tenga c es una mayuscula cambiamos su valor a true
                Mayusculas = true;
            if (char.IsDigit(c))//si el caracter que tenga c es un numero cambiamos su valor a true 
                num = true;
        }
    return Mayusculas && num;//la funcion retorna los valores bolenaos de mayusculas y numero 
}

*/


//Ejercicio 3:Simulación de cajero automático
static void Main(){//Funcion principal

    double saldo = 2000;// el saldo principal es de Q2000
    Console.WriteLine("Bienvenido");

    MostrarMenu(saldo);// llamamos la funcion que desglosa el menu    

}

static void MostrarMenu(double saldo){// la funcion del menu contiene las opciones que se pueden realizar en el cajero

    double cantidad;// declaramos la cantidad que se ingresaran para retirar o depositar
    Console.WriteLine("Ingrese el numero de las opciones");
    Console.WriteLine("1) Consultar saldo");
    Console.WriteLine("2) Retirar");
    Console.WriteLine("3) Depositar");
    Console.WriteLine("4) Salir");

    int opciones = Convert.ToInt32(Console.ReadLine());// guardamos el numero de la opcion elegida por el usuario

    switch (opciones){//leemos el numero de la opcion

        case 1:// consultar el saldo
            Console.WriteLine("Consultar saldo");
            ConsultarSaldo(saldo);//llamamos la funcion que consulta el saldo 
        break;

        case 2:// retirar
            Console.WriteLine("Retirar");
            Console.WriteLine("Su saldo es de: Q" + saldo );//mostramos el saldo actual
            Console.WriteLine("Ingrese la cantidad que desea retirar");//pedimos la cantidad a retirar
            cantidad = Convert.ToDouble(Console.ReadLine());//guardamos la cantidad
            saldo = Retirar(saldo,cantidad);//actualizamos el saldo
        break;

        case 3:// depositar
            Console.WriteLine("Depositar");
            Console.WriteLine("Su saldo es de: Q" + saldo);//mostramos el saldo actual
            Console.WriteLine("Ingrese la cantidad que desea depositar");//pedimos la cantidad a depositar
            cantidad = Convert.ToDouble(Console.ReadLine());//guardamos la cantidad
            saldo = Depositar(saldo,cantidad);//actualizamos el saldo
        break;

        case 4:// salir
            Console.WriteLine("Gracias por usar el cajero");
            return;
        
        default:// opcion incorrecta
            Console.WriteLine("La opcion es incorrecta");
        break;
    }

     Console.WriteLine();
    MostrarMenu(saldo);// actualizamos el saldo

}

static void ConsultarSaldo(double saldo){// esta funcion muestra el saldo actual

        Console.WriteLine("Su saldo actual es de: Q" + Math.Round(saldo, 2));// mostramos el saldo a dos decimales
        Console.ReadKey();

}


static double Depositar(double saldo, double cantidad){// esta funcion realiza el proceso del deposito

    if (cantidad > 0){// valida si la cantidad es mayor a 0
        
        saldo += cantidad;// suma la cantidad al saldo actual

        Console.WriteLine("Tu deposito fue de: Q" + cantidad);
        Console.WriteLine("Su saldo actual es de: Q" + Math.Round(saldo, 2));// mostramos el saldo a dos decimales
        Console.ReadKey();
    }

    else {// valida si la cantidad es menor a 0

    Console.WriteLine("Porfavor ingresa un valor positivo mayor a 0");// solicitamos que ingrese un valor positivo
    Console.ReadKey();

    }

    return saldo;//retornamos el saldo actualizado

}


static double Retirar(double saldo, double cantidad){//esta funcion muestra el procedimiento para retirar


    if (cantidad > saldo){//valida si la cantidad a retirar es mayor al saldo actual
        Console.WriteLine("Tu saldo es insuficiente para realizar este retiro");// si es mayor no se puede hacer el retiro
        Console.ReadKey();
    }

    if (cantidad <= saldo){//valida si la cantidad es menor o igual al saldo actual
        saldo -= cantidad;// resta la cantidad al saldo actual
        Console.WriteLine("Tu retiro fue de: Q" + cantidad);
        Console.WriteLine("Su saldo actual es de: Q" + Math.Round(saldo, 2));//mostramos el saldo a dos decimales
        Console.ReadKey();
    }

    return saldo;//retornamos el saldo actializado

}

}